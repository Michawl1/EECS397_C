/*
#include <iostream>
#include <fstream>
#include <string>
#include <time.h>

int main(const int argc, const char** argv) {
    std::srand(time(NULL)); //initialize the random number generator

    // Define input file locations and name.

    // Define output file location and name

    // Open the input file

    // Good to check if the input file exists and complain if it doesn't.

    //Create output file with the given name

    // Loop through to the end of the input file

    // For each line

    // copy from start to d where d not included to a variable

    // convert it to integer and assign it as the count

    // copy from d to the end (d is not included) to a variable

    // convert it to integer and assign it as the number of faces

    // loop over count
    // create random number using: ( std::rand() % number of faces ) + 1; )
    // sum all the random numbers

    // Convert the sum into string
    // Write the string into output file

    // loop shoud end here

    //close input file
    //close output file

    return 0;
}
*/