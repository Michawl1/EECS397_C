/**
 * Michael Thompson
 * EECS397
 * 1/23/2020
 */

#include <iostream>

using namespace std;

/*
int main()
{
    cout << "Hello world\n";
    return 0;
}
*/

/*
int main()
{
    int integer1;
    int integer2;
    int integer3;
    int sum_i;
    double sum_d;
    int avg_i;
    double avg_d;

    cout << "Enter first integer: \n";
    cin >> integer1;
    cout << "Enter second integer: \n";
    cin >> integer2;
    cout << "Enter third integer: \n";
    cin >> integer3;

    sum_i = integer1 + integer2 + integer3;
    sum_d = integer1 + integer2 + integer3;
    avg_i = sum_i / 3;
    avg_d = sum_d / 3;

    cout << "Sum is " << sum_i << endl;
    cout << "Average (int) is " << avg_i << endl;
    cout << "Average (double) is " << avg_d << endl;
}
*/

/*

ternary conditional operator (?:)

boolean condition ? value if true : value if false

*/

/*
int main()
{
    cout << 0 ? true : false;
}
*/
