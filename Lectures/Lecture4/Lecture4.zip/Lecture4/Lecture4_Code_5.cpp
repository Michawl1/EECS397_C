/*
//Fibonacci Series using Recursion
#include <iostream>
using namespace std;


int fib(int);

int main()
{
    int n = 9;
    cout << fib(n);
    return 0;
}

int fib(int n)
{
    if (n <= 1)
        return n;
    return fib(n - 1) + fib(n - 2);
}

*/