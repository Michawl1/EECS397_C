Michael Thompson
EECS 397 C/C++

To run part 1 or part 2 make sure that the other one is commented out so the main's do not conflict

part 1 is located in homework3part1.cpp
part 2 is located in homework3part2.cpp

part 1 is tied to dice_part_1.txt
part 2 is tied to dice_part_2.txt

as submitted, part 1 is active and part 2 is commented out